package cajeroautomatico;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class Cliente {
    private String nombre;
    private String tipoCuenta;
    private String banco;
    private String documentoIdentidad;
    private String numeroCuenta;
    private String contrasena;
    private double saldo;
    

    public Cliente(String nombre, String tipoCuenta, String banco, String documentoIdentidad,
                   String numeroCuenta, String contrasena, double saldo) {
        this.nombre = nombre;
        this.tipoCuenta = tipoCuenta;
        this.banco = banco;
        this.documentoIdentidad = documentoIdentidad;
        this.numeroCuenta = numeroCuenta;
        this.contrasena = contrasena;
        this.saldo = saldo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public String getBanco() {
        return banco;
    }

    public String getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public boolean verificarContrasena(String contrasena) {
        return this.contrasena.equals(contrasena);
    }

    public void retirar(double cantidad) {
        if (cantidad > 0 && saldo >= cantidad) {
            saldo -= cantidad;
            System.out.println("Retiro exitoso. Saldo restante: " + saldo);
        } else {
            System.out.println("Fondos insuficientes o cantidad inválida.");
        }
    }

    public void depositar(double cantidad, String banco) {
        double tasaImpuesto = tipoCuenta.equalsIgnoreCase("credito") ? 0.15 : 0.10;
        double cantidadConImpuesto = cantidad * (1 + tasaImpuesto);
        saldo += cantidadConImpuesto;
        System.out.println("Depósito exitoso en " + banco + ". Saldo actual: " + saldo);
    }
}

public class CajeroAutomatico {
    private Map<String, Cliente> clientes;
    private Map<String, List<String>> historialTransacciones;

    public CajeroAutomatico() {
        clientes = new HashMap<>();
        historialTransacciones = new HashMap<>();
    }

    public void registrarCliente(String nombre, String tipoCuenta, String banco, String documentoIdentidad,
                                 String numeroCuenta, String contrasena, double saldo) {
        Cliente cliente = new Cliente(nombre, tipoCuenta, banco, documentoIdentidad,
                                      numeroCuenta, contrasena, saldo);
        clientes.put(numeroCuenta, cliente);
        historialTransacciones.put(numeroCuenta, new ArrayList<>());
    }

    public boolean iniciarSesion(String numeroCuenta, String contrasena) {
        Cliente cliente = clientes.get(numeroCuenta);
        if (cliente != null && cliente.verificarContrasena(contrasena)) {
            System.out.println("Inicio de sesión exitoso. ¡Hola, " + cliente.getNombre() + "!");
            return true;
        } else {
            System.out.println("Inicio de sesión fallido. Verifique el número de cuenta y la contraseña.");
            return false;
        }
    }

    public void realizarRetiro(String numeroCuenta, double cantidad) {
        Cliente cliente = clientes.get(numeroCuenta);

        if (cliente != null) {
            cliente.retirar(cantidad);
            String registro = "Fecha: " + obtenerFechaActual() + ", Monto: -" + cantidad;
            historialTransacciones.get(numeroCuenta).add(registro);
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    public void realizarDeposito(String numeroCuenta, double cantidad, String banco, double tasaImpuesto) {
        Cliente cliente = clientes.get(numeroCuenta);

        if (cliente != null) {
            cliente.depositar(cantidad, banco);
            String registro = "Fecha: " + obtenerFechaActual() + ", Monto: +" + cantidad + ", Banco: " + banco;
            historialTransacciones.get(numeroCuenta).add(registro);
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }
    
    

    private String obtenerFechaActual() {
        // Implementación para obtener la fecha actual (simulada)
        return "20/08/2023";
    }

public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CajeroAutomatico cajero = new CajeroAutomatico();

        while (true) {
            System.out.println("Bienvenido al Cajero Automático");
            System.out.println("1. Crear cuenta");
            System.out.println("2. Iniciar sesión");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            if (opcion == 1) {
                System.out.print("Nombre: ");
                String nombre = scanner.nextLine();
                System.out.print("Tipo de cuenta (credito/debito): ");
                String tipoCuenta = scanner.nextLine();
                System.out.print("Banco: ");
                String banco = scanner.nextLine();
                System.out.print("Documento de identidad: ");
                String documentoIdentidad = scanner.nextLine();
                System.out.print("Número de cuenta: ");
                String numeroCuenta = scanner.nextLine();
                System.out.print("Contraseña numérica: ");
                String contrasena = scanner.nextLine();
                System.out.print("Saldo inicial: ");
                double saldoInicial = scanner.nextDouble();
                scanner.nextLine(); // Consumir el salto de línea después del número

                cajero.registrarCliente(nombre, tipoCuenta, banco, documentoIdentidad,
                        numeroCuenta, contrasena, saldoInicial);
                System.out.println("Cuenta creada exitosamente.");
       
            } else if (opcion == 2) {
                System.out.print("Número de cuenta: ");
                String numeroCuenta = scanner.nextLine();
                System.out.print("Contraseña numérica: ");
                String contrasena = scanner.nextLine();

                if (cajero.iniciarSesion(numeroCuenta, contrasena)) {
                    System.out.print("¿Desea realizar una transacción? (si/no): ");
                    String respuesta = scanner.nextLine();
                    if (respuesta.equalsIgnoreCase("si")) {
                        System.out.println("1. Retirar");
                        System.out.println("2. Depositar");
                        System.out.print("Seleccione una opción: ");
                        int opcionTransaccion = scanner.nextInt();
                        scanner.nextLine(); // Consumir el salto de línea después del número

                        if (opcionTransaccion == 1) {
                            System.out.print("Monto a retirar: ");
                            double monto = scanner.nextDouble();
                            scanner.nextLine(); // Consumir el salto de línea después del número
                            cajero.realizarRetiro(numeroCuenta, monto);
                        } else if (opcionTransaccion == 2) {
                            System.out.print("Monto a depositar: ");
                            double monto = scanner.nextDouble();
                            scanner.nextLine(); // Consumir el salto de línea después del número

                            System.out.println("Seleccione un banco para depositar:");
                            System.out.println("1. Bancolombia");
                            System.out.println("2. Daviplata");
                            // ... (otros bancos)
                            System.out.print("Seleccione una opción: ");
                            int opcionBanco = scanner.nextInt();
                            scanner.nextLine(); // Consumir el salto de línea después del número

                            String bancoElegido;
                            switch (opcionBanco) {
                                case 1:
                                    bancoElegido = "Bancolombia";
                                    break;
                                case 2:
                                    bancoElegido = "Daviplata";
                                    break;
                                // ... (otros casos para bancos)
                                default:
                                    bancoElegido = "Desconocido";
                                    break;
                            }

                            double tasaImpuesto = 0.0; // Inicializar tasa de impuesto

                            System.out.print("Tipo de transacción (retiro/deposito): ");
                            String tipoTransaccion = scanner.nextLine();

                            if (tipoTransaccion.equals("retiro")) {
                                switch (bancoElegido) {
                                    case "Bancolombia":
                                        tasaImpuesto = 0.10; // 10% de impuesto en retiros
                                        break;
                                    case "Daviplata":
                                        tasaImpuesto = 0.12; // 12% de impuesto en retiros
                                        break;
                                    // Agregar más casos para otros bancos y tasas de impuestos
                                }
                            } else if (tipoTransaccion.equals("deposito")) {
                                switch (bancoElegido) {
                                    case "Bancolombia":
                                        tasaImpuesto = 0.14; // 14% de impuesto en depósitos
                                        break;
                                    case "Daviplata":
                                        tasaImpuesto = 0.15; // 15% de impuesto en depósitos
                                        break;
                                    // Agregar más casos para otros bancos y tasas de impuestos
                                }
                            }

                            cajero.realizarDeposito(numeroCuenta, monto, bancoElegido, tasaImpuesto);
                        } else {
                            System.out.println("Opción inválida. No se realizará ninguna transacción.");
                        }
                    }
                }
            } else if (opcion == 3) {
                System.out.println("¡Hasta luego!");
                break;
            } else {
                System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
            }
        }
    }
}